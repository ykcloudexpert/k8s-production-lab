# Kubernetes Production Lab (Manual Deployment)

This repository contains a production-oriented Kubernetes lab for hands-on practice.

See full instructions inside this repository.

#!/bin/bash
echo Deploying prod lab
